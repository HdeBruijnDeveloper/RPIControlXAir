.. include:: ../INSTALL-windows.rst
